using scats # Подключение пакета

s = scats.api() # Создание экземпляра API

s.read_input!("Файлы/input") # Считывание входных данных